/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lche
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import java.util.TreeMap;
import java.util.Vector;
import static javafx.scene.input.DataFormat.IMAGE;
import javax.print.DocFlavor.URL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.RowFilter;
import javax.swing.UIManager;
import javax.swing.filechooser.FileSystemView;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreePath;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.MultiGraph;
import org.graphstream.ui.swingViewer.ViewPanel;
import org.graphstream.ui.view.View;
import org.graphstream.ui.view.Viewer;
import org.icepdf.ri.common.ComponentKeyBinding;
import org.icepdf.ri.common.SwingController;
import org.icepdf.ri.common.SwingViewBuilder;
import org.icepdf.ri.util.PropertiesManager;
import org.jdesktop.swingx.treetable.FileSystemModel;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

public class Visualization_all extends javax.swing.JFrame {

    public static JFrame parent;
    public static String outputPath;
    /**
     * Creates new form Visualization_all
     */
    public Visualization_all(JFrame frame, String outputFolder) {
        
        initComponents();
        //setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        
        outputPath = outputFolder;
        parent = frame;
        
        try
        {
            File file = new File("./test/sample_ids.txt");
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            
            String str = br.readLine();
            str = br.readLine();
            TreeMap<String, String> replicates = new TreeMap<String, String>();
            while(str!=null)
            {
                comboBoxCondition.addItem(str.split("\t")[3].trim());
                replicates.put(str.split("\t")[4].trim()+ ".0", "hello");
                str = br.readLine();
            }
            br.close();
            fr.close();
            
            for(String key:replicates.keySet())
            {
                comboBoxReplicate.addItem(key);
            }
            
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        
        //Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        //setSize(screenSize.width, screenSize.height);
        /**
         * re-initialize tree structure to the designated output folder.
         */
//        FileSystemModel fModel = new FileSystemModel();
//        fModel.setRoot(new File(outputFolder));
//        treeOutputFolder.setModel(fModel);
        

        /**
         * set condition alignment and FDR image display
         */
        System.out.println(outputFolder);
        openConditionAlignment(outputFolder + "RecallDatabase.pdf");
        openFDR(outputFolder + "FalseDiscoveryRate.pdf");
        /**
         * read the complex report to the table
         */
        try
        {
            DefaultTableModel model = (DefaultTableModel)tblPredictionOutput.getModel();
            File file = new File(outputFolder + "ComplexReport.txt");
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
           
            String str = br.readLine();
            str = br.readLine();
            int count = 0;
            while(str!=null)
            {
                count++;
                str = str.trim();
                Vector row = new Vector();
                row.add(count);
                row.add(str.split("\t")[0].trim());
                row.add(str.split("\t")[1].trim());
                row.add(str.split("\t")[2].trim());
                row.add(str.split("\t")[3].trim());
                row.add(Integer.parseInt(str.split("\t")[4].trim()));
                row.add(Double.parseDouble(str.split("\t")[5].trim()));
                row.add(Integer.parseInt(str.split("\t")[6].trim()));
                row.add(Double.parseDouble(str.split("\t")[7].trim()));
                row.add(Double.parseDouble(str.split("\t")[8].trim()));
                row.add(str.split("\t")[10].trim());
                row.add(str.split("\t")[11].trim());
                
                model.addRow(row);
                
                
                str = br.readLine();
            }
            br.close();
            fr.close();
            
            TableColumn col0 = tblPredictionOutput.getColumnModel().getColumn(0);
            col0.setPreferredWidth(3);
            TableColumn col1 = tblPredictionOutput.getColumnModel().getColumn(1);
            col1.setPreferredWidth(100);
            TableColumn col2 = tblPredictionOutput.getColumnModel().getColumn(2);
            col2.setPreferredWidth(5);
            TableColumn col5 = tblPredictionOutput.getColumnModel().getColumn(5);
            col5.setPreferredWidth(5);
            TableColumn col6 = tblPredictionOutput.getColumnModel().getColumn(6);
            col6.setPreferredWidth(5);
            TableColumn col7 = tblPredictionOutput.getColumnModel().getColumn(7);
            col7.setPreferredWidth(5);
            TableColumn col10 = tblPredictionOutput.getColumnModel().getColumn(10);
            col10.setPreferredWidth(10);
            TableColumn col11 = tblPredictionOutput.getColumnModel().getColumn(11);
            col11.setPreferredWidth(10);
            
        }catch(IOException e)
        {
            System.out.println("doesnt exist");
            JOptionPane.showMessageDialog(null, "The prediction file \'ComplexReport.txt\' does NOT exist!", "Alert", JOptionPane.ERROR_MESSAGE);
        }
        
        makeTableColor(tblPredictionOutput);
        setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblPredictionOutput = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        txtQuery = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        comboBoxPrediction = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        comboBoxReported = new javax.swing.JComboBox<>();
        btnSearchPR = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        comboBoxCondition = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        comboBoxReplicate = new javax.swing.JComboBox<>();
        btnSearchCR = new javax.swing.JButton();
        spConditionAlignment = new javax.swing.JScrollPane();
        spFDRrate = new javax.swing.JScrollPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Prediction Reports");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Summary of prediction results"));

        tblPredictionOutput.setAutoCreateRowSorter(true);
        tblPredictionOutput.setBackground(new java.awt.Color(204, 204, 204));
        tblPredictionOutput.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Number", "Complex Name", "Condition", "Members", "Stoichiometry", "#Members", "Replicate", "Apex Peak", "Prediction Score as A Complex", "Completeness", "Prediction Result", "Is Reported?"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblPredictionOutput.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
        tblPredictionOutput.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPredictionOutputMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblPredictionOutput);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtering table"));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Content Filter (Case sensitive)"));

        txtQuery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQueryActionPerformed(evt);
            }
        });
        txtQuery.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtQueryKeyTyped(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtQueryKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtQuery, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(113, 113, 113))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtQuery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Prediction Filter"));

        comboBoxPrediction.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Positive", "Negative" }));

        jLabel9.setText("and");

        comboBoxReported.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Reported", "Novel" }));

        btnSearchPR.setText("Search");
        btnSearchPR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchPRActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(comboBoxPrediction, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(comboBoxReported, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnSearchPR))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxPrediction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(comboBoxReported, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSearchPR))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Condition Filter"));

        jLabel11.setText("and");

        btnSearchCR.setText("Search");
        btnSearchCR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchCRActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(comboBoxCondition, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)
                        .addComponent(comboBoxReplicate, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnSearchCR))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxCondition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(comboBoxReplicate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSearchCR))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1285, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(328, 328, 328)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(401, 401, 401)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(123, 123, 123))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        spConditionAlignment.setViewportBorder(javax.swing.BorderFactory.createTitledBorder("Condition alignment"));

        spFDRrate.setViewportBorder(javax.swing.BorderFactory.createTitledBorder("FDR rate"));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(spConditionAlignment, javax.swing.GroupLayout.PREFERRED_SIZE, 776, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(spFDRrate))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1601, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(spConditionAlignment, javax.swing.GroupLayout.DEFAULT_SIZE, 493, Short.MAX_VALUE)
                    .addComponent(spFDRrate))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblPredictionOutputMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPredictionOutputMouseClicked
        // TODO add your handling code here:
        /**
         * if a column in the table is double-clicked, then a new frame is open for displaying the co-elution profile of the selected complex.
         */
        if (evt.getClickCount() == 2) 
        {
            int row = tblPredictionOutput.getSelectedRow();
            String name = tblPredictionOutput.getValueAt(row, 1).toString().trim();
            String condition = tblPredictionOutput.getValueAt(row, 2).toString().trim();
            String rep = tblPredictionOutput.getValueAt(row, 6).toString().trim();
            String prediction = tblPredictionOutput.getValueAt(row, 10).toString().trim();
            String reported = tblPredictionOutput.getValueAt(row, 11).toString().trim();
            CoElutionDisplay s = new CoElutionDisplay(outputPath, name, condition, rep, prediction, reported);
            s.setVisible(true);
        }
    }//GEN-LAST:event_tblPredictionOutputMouseClicked

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        // TODO add your handling code here:
        parent.setEnabled(true);
    }//GEN-LAST:event_formWindowClosed

    private void txtQueryKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtQueryKeyReleased
        // TODO add your handling code here:
        String query = txtQuery.getText();
        filterTable(query);
    }//GEN-LAST:event_txtQueryKeyReleased

    private void txtQueryKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtQueryKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQueryKeyTyped

    private void txtQueryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQueryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQueryActionPerformed

    private void btnSearchPRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchPRActionPerformed
        // TODO add your handling code here:
        String prediction = comboBoxPrediction.getSelectedItem().toString();
        String reported = comboBoxReported.getSelectedItem().toString();
        filterReportedPrediction(prediction, reported);
    }//GEN-LAST:event_btnSearchPRActionPerformed

    private void btnSearchCRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchCRActionPerformed
        // TODO add your handling code here:
        String condition = comboBoxCondition.getSelectedItem().toString();
        String replicate = comboBoxReplicate.getSelectedItem().toString();
        filterConditionReplicate(condition, replicate);
    }//GEN-LAST:event_btnSearchCRActionPerformed

    public static void makeTableColor(JTable table) 
    {
        try {
            DefaultTableCellRenderer tcr = new DefaultTableCellRenderer() {
 
                public Component getTableCellRendererComponent(JTable table,
                        Object value, boolean isSelected, boolean hasFocus,
                        int row, int column) {
                    
                    if (table.getValueAt(row, 11).toString().equals("Reported") && table.getValueAt(row, 10).toString().equals("Negative")) 
                    {
                        setBackground(new Color(0xff6464));
                    }
                    else if(table.getValueAt(row, 11).toString().equals("Reported") && table.getValueAt(row, 10).toString().equals("Positive"))
                    {
                        setBackground(new Color(0xfdbf50));
                    }
                    else if(table.getValueAt(row, 11).toString().equals("Novel") && table.getValueAt(row, 10).toString().equals("Positive"))
                    {
                        setBackground(new Color(0x00be65));
                    }
                    else
                    {
                        setBackground(new Color(0xce76ee));
                    }
                return super.getTableCellRendererComponent(table, value,
                            isSelected, hasFocus, row, column);
                }
            };
            for (int i = 0; i < table.getColumnCount(); i++) {
                table.getColumn(table.getColumnName(i)).setCellRenderer(tcr);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
 
    }
    
    private void filterTable(String query)
    {
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>((DefaultTableModel)tblPredictionOutput.getModel());
        tblPredictionOutput.setRowSorter(tr);
        try 
        {
            tr.setRowFilter(RowFilter.regexFilter(query));
        }catch (java.util.regex.PatternSyntaxException e)
        {
            return;
        }
    }
    
    public void filterReportedPrediction(String prediction, String reported) 
    {
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>((DefaultTableModel)tblPredictionOutput.getModel());
        tblPredictionOutput.setRowSorter(tr);
        
        ArrayList<RowFilter<Object,Object>> pr = new ArrayList<RowFilter<Object,Object>>();
        System.out.println(tblPredictionOutput.getColumnModel().getColumn(10).getIdentifier());
        RowFilter<Object,Object> predictionFilter = RowFilter.regexFilter(prediction, tblPredictionOutput.getColumnModel().getColumnIndex(tblPredictionOutput.getColumnModel().getColumn(10).getIdentifier()));
        RowFilter<Object,Object> reportedFilter = RowFilter.regexFilter(reported, tblPredictionOutput.getColumnModel().getColumnIndex(tblPredictionOutput.getColumnModel().getColumn(11).getIdentifier()));
        pr.add(predictionFilter);
        pr.add(reportedFilter);
        RowFilter<Object,Object> filter = RowFilter.andFilter(pr);
        tr.setRowFilter(filter);
    }
    
    public void filterConditionReplicate(String condition, String replicate) 
    {
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>((DefaultTableModel)tblPredictionOutput.getModel());
        tblPredictionOutput.setRowSorter(tr);
        
        ArrayList<RowFilter<Object,Object>> cr = new ArrayList<RowFilter<Object,Object>>();
        System.out.println(tblPredictionOutput.getColumnModel().getColumn(10).getIdentifier());
        RowFilter<Object,Object> conditionFilter = RowFilter.regexFilter(condition, tblPredictionOutput.getColumnModel().getColumnIndex(tblPredictionOutput.getColumnModel().getColumn(2).getIdentifier()));
        RowFilter<Object,Object> replicateFilter = RowFilter.regexFilter(replicate, tblPredictionOutput.getColumnModel().getColumnIndex(tblPredictionOutput.getColumnModel().getColumn(6).getIdentifier()));
        cr.add(conditionFilter);
        cr.add(replicateFilter);
        RowFilter<Object,Object> filter = RowFilter.andFilter(cr);
        tr.setRowFilter(filter);
    }
    
    public void openConditionAlignment(String file)
    {
        try
        {
            ResourceBundle messageBundle = ResourceBundle.getBundle(PropertiesManager.DEFAULT_MESSAGE_BUNDLE); 
            PropertiesManager properties = new PropertiesManager(System.getProperties(),messageBundle); 

            properties.set(PropertiesManager.PROPERTY_DEFAULT_ZOOM_LEVEL, "0.8");
            SwingController control = new SwingController();
            SwingViewBuilder factory = new SwingViewBuilder(control, properties);
            JPanel pdfViewer = factory.buildViewerPanel();
            ComponentKeyBinding.install(control, pdfViewer);
            control.getDocumentViewController().setAnnotationCallback(
                new org.icepdf.ri.common.MyAnnotationCallback(
                        control.getDocumentViewController()));
            control.openDocument(file);
            spConditionAlignment.setViewportView(pdfViewer);
            
        }catch (Exception e)
        {
            
        }
    }
    
    public void openFDR(String file)
    {
        try
        {
            ResourceBundle messageBundle = ResourceBundle.getBundle(PropertiesManager.DEFAULT_MESSAGE_BUNDLE); 
            PropertiesManager properties = new PropertiesManager(System.getProperties(),messageBundle); 

            properties.set(PropertiesManager.PROPERTY_DEFAULT_ZOOM_LEVEL, "0.8");  
            SwingController control = new SwingController();
            SwingViewBuilder factory = new SwingViewBuilder(control, properties);
            JPanel pdfViewer = factory.buildViewerPanel();
            ComponentKeyBinding.install(control, pdfViewer);
            control.getDocumentViewController().setAnnotationCallback(
                new org.icepdf.ri.common.MyAnnotationCallback(
                        control.getDocumentViewController()));
            control.openDocument(file);
            spFDRrate.setViewportView(pdfViewer);
            
        }catch (Exception e)
        {
            
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearchCR;
    private javax.swing.JButton btnSearchPR;
    private javax.swing.JComboBox<String> comboBoxCondition;
    private javax.swing.JComboBox<String> comboBoxPrediction;
    private javax.swing.JComboBox<String> comboBoxReplicate;
    private javax.swing.JComboBox<String> comboBoxReported;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane spConditionAlignment;
    private javax.swing.JScrollPane spFDRrate;
    private javax.swing.JTable tblPredictionOutput;
    private javax.swing.JTextField txtQuery;
    // End of variables declaration//GEN-END:variables
}
